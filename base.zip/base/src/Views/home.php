<?=$this->fetch('commons/header.php', $data)?>

<?=$this->fetch('commons/footer.php', $data)?>