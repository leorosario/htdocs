	<footer>

	</footer>
    <script src="<?=URL_BASE?>resources/js/jquery/jquery.min.js"></script>
	<script src="<?=URL_BASE?>resources/js/js.min.js"></script>
</body>
</html>